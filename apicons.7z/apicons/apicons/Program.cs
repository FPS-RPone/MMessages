﻿using Microsoft.AspNetCore.SignalR.Client;

namespace apicons
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string? nickname = null;

            HubConnection connection = new HubConnectionBuilder()
                .WithUrl(@"http://localhost:5255/chatroom")
                .WithAutomaticReconnect()
                .Build();

            connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                    var newMessage = $"{user}: {message}";
                    Console.WriteLine(newMessage);
            });

            char? choice = null;

            while (choice != 'y')
            {
                while (nickname == null || nickname == "")
                {
                    Console.Write("Ваш никнейм: ");
                    nickname = Console.ReadLine();
                }

                Console.WriteLine("Вы уверены? y для продолжения, n для повторного выбора никнейма");
                choice = Console.ReadKey().KeyChar;
                Console.WriteLine();

                if (choice == 'n')
                    nickname = null;
            }

            try
            {
                //Подключение к хабу
                Task.Run(() => { 
                    connection.StartAsync();
                    Console.Clear();
                    Console.WriteLine("Вы вошли в чат");
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            while (true)
            {
                string? message = Console.ReadLine();
                if (message != null && message != "")
                {
                    Task.Run(() => {
                         connection!.InvokeAsync("SendMessage", nickname, message);
                    });
                }
            }
        }
    }
}
